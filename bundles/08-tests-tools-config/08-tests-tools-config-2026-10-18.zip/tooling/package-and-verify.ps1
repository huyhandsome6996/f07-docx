$ErrorActionPreference = 'Stop'
# Packaging artifacts only; this script never changes the application or DB.
$bundle = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$zipPath = $bundle + '.zip'
if (Test-Path -LiteralPath $zipPath) { throw "ZIP already exists; preserve it and choose another output name: $zipPath" }
$manifestPath = Join-Path $bundle 'MANIFEST-SHA256.csv'
$items = @(Get-ChildItem -LiteralPath $bundle -Recurse -File | Where-Object { $_.FullName -ne $manifestPath } | Sort-Object FullName)
$rows = foreach ($item in $items) {
    [pscustomobject]@{
        Path = [IO.Path]::GetRelativePath($bundle, $item.FullName).Replace('\','/')
        Bytes = $item.Length
        SHA256 = (Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash
    }
}
$rows | Export-Csv -LiteralPath $manifestPath -NoTypeInformation -Encoding utf8
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($bundle, $zipPath, [IO.Compression.CompressionLevel]::Optimal, $false)
$archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    foreach ($row in $rows) {
        $entry = $archive.GetEntry($row.Path)
        if ($null -eq $entry) { throw "Missing archive entry: $($row.Path)" }
        $stream = $entry.Open()
        try { $actual = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)) }
        finally { $stream.Dispose() }
        if ($actual -ne $row.SHA256) { throw "Archive checksum mismatch: $($row.Path)" }
    }
    if ($null -eq $archive.GetEntry('MANIFEST-SHA256.csv')) { throw 'Missing checksum manifest' }
    [pscustomobject]@{ ZIP=$zipPath; FileCount=$rows.Count+1; VerifiedHashes=$rows.Count; ZIPBytes=(Get-Item -LiteralPath $zipPath).Length }
} finally { $archive.Dispose() }

