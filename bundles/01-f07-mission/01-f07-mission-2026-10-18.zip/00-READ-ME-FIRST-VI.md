# Bàn giao F07 cho chat mới — 18/10/2026

## Câu mở đầu để dán vào chat mới
Tôi giao bạn phụ trách kiểm thử, sửa lỗi và hoàn thành F07 của Family Bridge theo đúng đầu ra trong gói này. Giải nén, đọc 01-START-HERE-EN.md rồi 02-F07-DETAILED-MISSION-VI.md và các tài liệu/mã nguồn liên quan. Phản hồi bằng tiếng Việt. Làm trên nhánh F07 hiện có, kiểm thử độc lập bằng API thật và giao diện Mini App thật. Không merge main, không tự deploy, không đụng công việc F02 của chat trước hoặc web của người khác. Báo cáo bằng chứng, lỗi đã sửa và URL local để tôi tự kiểm thử.

## Mục tiêu cốt lõi F07
1. Chọn cảm xúc/ngày, ghi chú tùy chọn và lưu riêng tư.
2. Xem lịch sử cá nhân và sửa đúng mục của mình.
3. Chọn một mục + người nhận đang kết nối + xem trước đúng nội dung/phiên bản rồi xác nhận chia sẻ.
4. Quản lý từng quyền chia sẻ, thu hồi một mục/người nhận.
5. Người nhận chỉ xem nội dung còn quyền; thu hồi/hủy kết nối/sửa chưa chia sẻ lại chặn lần đọc tiếp.
6. Các tài khoản/role/admin/kết nối sẵn không tự đọc tâm sự riêng của nhau.

## Tình trạng đã kiểm tra từ GitHub
- Repo: https://github.com/huyhandsome6996/family-bridge
- Main: 571abcb7916954964d82e0aa27e7661e7d7efd83.
- Nhánh F07: tinh-nang/f07-tam-trang-va-chia-se-us015-us026.
- Head F07: f8fc6a4cc8bbceb2b115bbadc06619734142cad7.
- F07 hiện chậm main **61 commit**, ahead0; cần đồng bộ main mới an toàn trước sửa.
- F02: tinh-nang/f02-dong-hanh-bon-tuan-us036-us044; head689531e06a593d39462041329c0581b4ec1b0aba.
- Consent mới: codex/consent-stitch-responsive; head85666b9 tại lần đọc (fetch SHA đầy đủ trước dùng).
- **Chat cũ tiếp tục chịu trách nhiệm hoàn thành F02. Chat mới sở hữu F07.**

Không lấy việc nhánh có module/tests làm bằng chứng F07 đã dùng được. Các lỗi nghi vấn trong prompt cũ phải tái hiện trên baseline mới trước kết luận.

## Quyết định hiện hành thắng bối cảnh cũ
- Đăng nhập HS/PH; identity/role do backend trả. Zalo SDK cũ dormant.
- Admin gán cặp phụ huynh–học sinh; nguồn admin_provisioned tạo connection active, invite có thể NULL. Tính năng A đã có code trên main. Tài liệu agent báo backfill production 50 cặp CHƯA thực hiện vì thiếu DB access; không tự tuyên bố mọi người đã active.
- Chương trình/thỏa ước F02 vẫn tự nguyện; thỏa ước vẫn cần hai người tự xác nhận.
- Consent nghiên cứu/AI không mặc định chấp nhận.
- Web và Mini App có UI/source tree riêng; dùng chung API/headless.
- Quản lý quyền riêng tư F15 phải phối hợp; không sửa owner khác bằng cách ghi đè.

## Trong gói
- 01-START-HERE-EN.md: nhiệm vụ cho chat mới và bối cảnh cập nhật.
- 02-F07-DETAILED-MISSION-VI.md: prompt chi tiết đội10agent đã cập nhật mốc Git/auth mới; bao gồm contract/test matrix và nguồn cần đọc.
- 03-F07-ACCEPTANCE-VI.md: đầu ra và tiêu chí đạt.
- 04-SYSTEM-MAP-AND-READING-VI.md: bản đồ hệ thống, các nguồn và ranh giới.
- 05-F02-OWNERSHIP-AND-COORDINATION-VI.md: phối hợp với chat F02.
- sources/main/: toàn bộ snapshot tracked first-party repo từ mainSHA ở trên (895file tại thời điểm export); không có .git, env secret, DB local, node_modules hoặc token của chat.
- sources/f07-branch/: module/backend/mobile/docs F07 tại head nhánh hiện có, để so sánh; không phải baseline triển khai.
- sources/f02-reference/: handover/scope F02 để hiểu vùng tiếp giáp.
- sources/consent-reference/: thay đổi/handover Consent ở nhánh riêng, đọc tham khảo, không tự merge.
- references/: file Word yêu cầu15tính năng và bản trích xuất đã đọc.
- MANIFEST-SHA256.csv: checksum tất cả file ngoài manifest.

## Giới hạn bằng chứng
Phiên đóng gói kiểm tra refs/source/documents. Chưa chạy lại toàn bộ F07 runtime, chưa kiểm MySQL hoặc Zalo thiết bị thật; chat mới phải thực hiện và báo NOT_RUN trung thực nếu thiếu môi trường. Gói này không chứa mật khẩu người dùng hoặc DB production. Tạo fixture local riêng, không lấy100tài khoản thật để sửa/xóa/thu hồi thử.

