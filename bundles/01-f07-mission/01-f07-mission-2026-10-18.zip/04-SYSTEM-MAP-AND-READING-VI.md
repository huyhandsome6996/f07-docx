# Bản đồ Family Bridge cho chat F07

## Sản phẩm
Gia đình chủ động mở lời và lắng nghe; mỗi người giữ quyền dữ liệu riêng.15tính năng theo Word của Huy, cùng admin và tài khoản lớp. Không chẩn đoán, không giám sát con tự động, không dùng khảo sát/tiến độ để ép tham gia.

| Mã | Nội dung | Điểm tiếp giáp F07 |
| --- | --- | --- |
| F01 | Identity/session/consent/canonical connections | Principal, active pair, generation, logout |
| F02 | Giáo trình4tuần, tiến độ, sổ giấy/thỏa ước | Chỉ dẫn dùng mood, không mở quyền đọc; chat cũ phụ trách |
| F03 | Thẻ cảm xúc | Phân biệt thẻ gửi với mood nhật ký |
| F04 | AI diễn đạt | AI draft riêng, không gửi vào mood tự động |
| F05 | Hộp thư/phản hồi | Không biến mood grant thành đọc mọi thư |
| F06 | Nháp/pause300s | Không auto-send, help luôn mở |
| F07 | Mood/history/share item | Phạm vi chính |
| F08 | Nhật ký riêng/song hành | Domain riêng, grants phải phối hợp F15 |
| F09 | Hoạt động/lời mời/bài học | Cùng connection protocol |
| F10 | Cần được lắng nghe | Tín hiệu tự nguyện, không share mood tự động |
| F11 | Điểm tựa dự phòng | Không auto-forward tâm sự |
| F12 | Trường/danh bạ/hẹn riêng | Người hỗ trợ không có quyền mặc định đọc mood |
| F13 | Trợ giúp | Truy cập được khi chưa login/API lỗi theo contract |
| F14 | Khảo sát tự nguyện/tổng hợp | Không raw data/admin mood bypass |
| F15 | Grant/revoke/unlink/delete | Bắt buộc integration thật với F07 |
| F16/classroom | HS/PH provisioning/login/admin pairs | Role server, pairsourceadmin không thay privacy |
| admin_core/B16 | Named caps/scope/content lifecycle | Không is_staff bypass/private reads |

## Runtime
Frontend: HTML/CSS/vanilla ESModules +Vite. Hai UI riêng web/ và zalo-mini-app/. Shared headless packages/family_bridge_shared/ và mobile_core. zmp-sdk chỉ dùng qua adapter khi đường legacy được bật lại có chủ đích, không trong mood pages.

Backend: Python/Django/DRF; registry/urls mount app packages/family_bridge_features/. Backend thật ở backend/; harness test ở tests/feature-lab/. DB deployment MySQL/TiDB; SQLite chỉlocal. Render backend hiện hữu https://family-bridge-backend.onrender.com ; web https://family-bridge-web.onrender.com ; không suy deployedSHA từ gitmainSHA.

F07 source:
- packages/family_bridge_features/f07_mood/{models,auth,api,urls}.py
- services/{mood,registry}.py; tests/test_f07.py; migrations/
- packages/family_bridge_mobile/f07_mood/{api.js,pages/,tests/}
- docs/features/f07/
- OfficialMiniApp router/pages/adapter must be traced; module tồn tại không chứng minh đã wire.

Nguồn Word trích yêu cầu F07 nằm references/. Toàn Word có15feature cho bối cảnh; chỉ hoàn thiện F07 theo phạm vi.

## Thứ tự đọc
1.01nhiệm vụ,02prompt đầy đủ,03nghiệm thu.
2.sources/main/AGENTS.md,nestedAGENTS; project-scope; skillsDSA/security/UI/workflow và rules liên kết.
3.docs/product/{decision-register,user-flows,workflow-state-machines,access-sharing-matrix,workflow-acceptance}.md.
4.docs/data/erd.md; docs/contracts/api-foundation.md và openapi.yaml.
5.docs/project/branch-reorganization/{branches.json,shared-integration.md}; kiểm tra PR mới, không coi lock15/10 còn đúng mãi.
6.docs/handover/web-miniapp-separation/ và admin-provisioned-pairs-and-consent/.
7.F07 +F15 +session/auth/connection provider +official UI source cùng tests.
8.Featuredocs/handover khác khi có consumer phụ thuộc.

## Cách chạy
Đọc lệnh chính xác từ CI/README của snapshot mới. tests/feature-lab là harness, không đổi nó thành production auth. Cần localfixtures riêngHS/PH, activeadminpair, người lạ, admincap, serviceconsent tựsetuptrongtest. Không dùng Excel100tài khoản/mật khẩu hoặc configRenderbí mật; gói không chứa chúng.

