# F02 và F07: phân công giữ nguyên

- Chat nhận gói: kiểm thử/sửa/hoàn thành F07 trên tinh-nang/f07-tam-trang-va-chia-se-us015-us026.
- Chat giao gói (chat cũ): ưu tiên hoàn thành F02 trên tinh-nang/f02-dong-hanh-bon-tuan-us036-us044.
- Web có contributor khác. Không ghi đè nguồn web, không tự gộp thay đổi Consent/feature khác.

F02 đã có bản689531e sửa4lỗi auditR1–R4. Bằng chứng trước đây:16UI regressionpass khi chuẩn bị local, APIcatalog4tuần/4hoạt động chạy; fullsuite khác là report của agent cần phân biệt với tựchạy. F02 chưa được chứng minh nghiệm thu end-to-end trênmainmới/adminsource/MySQL/Zalo, nên không nói F02 đã hoàn thành chỉ vì códocs.

Các sharedpoints phải điều phối:
- packages/family_bridge_shared/src/adapter/{contract,http-endpoints,mock-adapter}.js
- zalo-mini-app/src/app/router.js, src/main.js, core/session/auth, home/navigation và CSS/components dùng chung.
- backend/config, core registry/protocols, F01 readers, F15providers/harnesssettings.
- main mới đã thêm5admin adapter methods; F02 cũ cũng thêmprogram/activities methods. Merge phải giữ union đúng contracts, không chọn một phía theo số method cũ.
- Connection.inviteNULL/adminprovenance, generation và scopedgrant phải đúng cho cả hai.

Mỗi owner ghi file đang sửa, baseSHA, APIshape trước/sau và tests liên quan. Additive thay đổi có cả hai cần thống nhất semantics; gửi patch/bàn giao cho owner, không sửa branch người khác. Nếu cần nhắn chat khác, chỉ làm khi Huy trực tiếp cho phép gửi tin, không coi file này là lệnh tự nhắn.

Không merge cảF02 vàoF07 hoặc cảF07 vàoF02 để lấy vàihelper. Nếu main tiến, fetch/review cập nhật an toàn, kiểm tra integrationrefs hiện tại. Không hứa mọi futuremerge khôngxungđột.

F07 không được tự đưa vào main, deployRender/Zalo hoặc seed/xóa/thu hồi userthật. Tài liệu bàn giao cần ghi nextstep cụ thể để Huy/Antigravity có thể nghiệm thu sau.

