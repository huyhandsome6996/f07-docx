# NEW CHAT MISSION — OWN F07 AND PROVE ITS USER OUTCOMES
Date:18October2026, Vietnam UTC+7.
Repository:https://github.com/huyhandsome6996/family-bridge
Target existing branch:tinh-nang/f07-tam-trang-va-chia-se-us015-us026.

Communicate with Huy in Vietnamese. The product UI and user-facing handover must be Vietnamese.

## What you own
You are responsible for understanding the whole Family Bridge architecture, independently testing F07 and completing the actual F07 product outputs. Read 00-READ-ME-FIRST-VI.md, the full detailed mission02, acceptance03 and map04 before acting. A different chat retains F02. Protect its working branch and shared-file ownership.

Do not respond merely "I understand". Inventory, reproduce, implement necessary fixes, run realistic tests, review, prepare an existing-branch Draft PR and hand off working local URLs plus evidence. No main merge/push, production migrations/data mutation or deployment is authorized by this F07 handoff.

## Refresh before coding
The included main snapshot is571abcb7916954964d82e0aa27e7661e7d7efd83.
F07 isf8fc6a4cc8bbceb2b115bbadc06619734142cad7, currently61commits behind and0ahead.
F02 is689531e06a593d39462041329c0581b4ec1b0aba.
These are reference anchors. Fetch origin, read current root/nested AGENTS and latest contracts, inventory dirty worktrees/PRs and record full actual SHAs. Do not reset to these snapshots or force-push a concurrent agent's changes. Sync latest main safely into the existing F07 branch in an isolated worktree.

Main now includes DEC-24/CAP-23/WF-25 and administrator-provisioned active parent/student connections. Connection.invite may beNULL; source/admin/batch provenance is separate from user confirmations. Use the canonical active connection protocol, not invite existence or login-code inference. Production backfill completion is NOT established by source merge.

Consent redesign is oncodex/consent-stitch-responsive, not blanket permission to merge someone else's UI. Preserve the separated web/ and zalo-mini-app/ architecture.

## Definition of done: actual F07 outcomes
- Signed-in user creates today's emotion/note with private default and revisits it after re-login.
- The official Mini App navigation/page/adapter really calls the production-style Django API and database.
- Owner history/detail/edit authorization is correct; owner is determined by session.
- One selected item, one selected current recipient, exact preview/version and explicit sharing confirmation.
- Recipient lists/details disclose only current valid grants on current itemrevision and current connectiongeneration.
- Edit, revoke, unlink and actor/session switch cannot leave a bypass through direct IDs, caches, late responses or future reconnection.
- Re-share after revoke/edit has correct semantics. Missing provider/connection reader fails closed.
- F15 overview/revoke/deletion integration uses real registered providers; no "pending wiring" hidden behind passing mocks.
- Role/admin/assigned family relationship gives no blanket access.
- ActorHS and actorPH both use server identity; role preview selection cannot grant authority.
- Help stays accessible; no automatic sharing or research acceptance.
- Domain constraints/date/timezone/one-item-per-day/note bounds follow the current agreed contract, with real database race verification where available.
- Local SQLite/browser evidence is honestly separated from MySQL/Zalo-device evidence.

Use03acceptance and the detailed02matrix to prove these. Do not shrink scope to only19historical module tests.

## Review model
The earlier F07 assignment requested10agent roles. Follow the real team/ownership/reviewer plan in02 if your environment supports delegation. If simultaneous capacity is smaller, run real agents in documented waves; report actual concurrency/session IDs. Do not fabricate10agents, private conversations or test execution. Lead plus9roles counts10total.

## How to use included sources
sources/main/ is a complete tracked-code snapshot with project docs and feature modules, not a Git checkout or a deployment.
sources/f07-branch/ shows the older branch-owned code for comparison.
sources/f02-reference/ and consent-reference/ are reference, not permission to import unreviewed feature changes.
Read current live repo after fetching before modifying. Full-repo understanding means map modules, ownership and runtime path then read relevant code deeply; do not claim to have read every binary/vendor/dependency.

## Static audit clues — reproduce before claiming a finding
The prior source review found possible owner-id keyword mismatch, absent reader fail-open, missing connection generation checks, stale previewrevision, revoked-share reuse, unbounded/stale recipient list and create races. These are source-level clues, NOT new runtime proof. Retest against latest integrated main; report fixed/not reproducible/still failing and attach minimal regression tests with real payload shapes.

## Handover
Deliver:
- concise Vietnamese business explanation;
- source/fullSHA/baseline and ownership report;
- acceptance matrix expected/actual with API/UI evidence;
- focused commits on the existing F07 branch and correct Draft PR;
- deterministic synthetic local setup and working login/history/share/recipient URLs;
- test credentials for those local fixtures without printing or exporting actual user secrets;
- screenshots, relevant test/build/DB/query counts and remaining NOT_RUN;
- instructions for Antigravity to deploy a later reviewed Testing build.

Do not merge main, activate public release, publish teacher content or alter production users to manufacture a success screenshot. Do not change F02 just because both features use shared privacy/session/connection code. Continue until concrete deliverables are met or a genuine external blocker prevents the remaining step.

