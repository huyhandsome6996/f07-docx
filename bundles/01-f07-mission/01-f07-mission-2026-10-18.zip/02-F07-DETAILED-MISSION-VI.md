# FAMILY BRIDGE — ĐỘI 10 AGENT HOÀN THIỆN F07 TÂM TRẠNG, LỊCH SỬ VÀ CHIA SẺ TỪNG MỤC

Ngày lập: **17/10/2026**; cập nhật bàn giao **18/10/2026**, múi giờ Việt Nam (UTC+7).

Người giao: Huy. Người nhận: coding agent trưởng nhóm và đội agent thực thi.

**Đây là nhiệm vụ làm sản phẩm hoàn chỉnh có bằng chứng: đọc repo, phân công 10 agent, triển khai, phản biện độc lập, kiểm thử, sửa lỗi, push đúng nhánh và bàn giao. Không dừng ở kế hoạch hoặc vài tests sẵn có. Không tự merge main và không tự deploy.**

## 1. Mục tiêu và quyền thực hiện

Trong khi agent khác đang hoàn thiện F02, hãy hoàn thiện **F07 — Ghi nhận tâm trạng và chia sẻ từng mục**, để người dùng Mini App thật có thể:

1. Chọn cảm xúc hôm nay, thêm ghi chú tùy chọn và lưu **riêng tư mặc định**.
2. Xem lịch sử cá nhân, mở từng ngày/mục, sửa đúng mục và xem thống kê mô tả của chính mình.
3. Chọn **đúng một mục, đúng người nhận, đúng phiên bản nội dung**, xem trước rồi tự xác nhận chia sẻ.
4. Biết rõ từng mục hiện đang chia sẻ cho ai; thu hồi một quyền mà không ảnh hưởng những mục/người nhận khác.
5. Người nhận chỉ xem đúng mục còn quyền; bị thu hồi/hủy kết nối/sửa nội dung chưa chia sẻ lại thì không tiếp tục đọc qua API hay cache ứng dụng.

Làm phần giao diện Mini App và backend/integration thực sự cần cho F07, giữ nguyên mục đích và hợp đồng hệ thống. Không biến F07 thành ứng dụng chẩn đoán, bảng giám sát con cái, dashboard đọc tâm sự cho thầy hoặc chức năng chia sẻ toàn bộ lịch sử.

Huy cho phép làm kỹ, làm lâu và phối hợp xuyên nhiều vòng đến khi đạt chất lượng. Không tự đặt hạn dừng 30–60 phút hoặc bỏ phần khó để “tiết kiệm thời gian”. Nhưng cũng không kéo dài bằng chờ giả, chạy lặp tests đã pass không có thay đổi, benchmark vô ích hoặc tạo tài liệu thay cho code. Nếu gặp blocker thật, hoàn tất phần độc lập và bàn giao chính xác việc còn thiếu, không báo đã xong.

**Được phép:** đọc repo/PR/tài liệu liên quan; làm trên worktree riêng; sửa trong phạm vi được điều phối; dùng dữ liệu synthetic và database test; chạy checks; commit/push nhánh F07 hiện có; mở/cập nhật Draft PR và tài liệu bàn giao.

**Không được phép trong nhiệm vụ này:** push main/merge PR, force-push, xóa/ghi đè nhánh khác, sửa source giao diện web, deploy Render/Zalo/Cloudflare, apply migration/seed/publish vào DB production, thay mật khẩu/cấp quyền/thực hiện consent hay kết nối thay người thật, công bố nội dung thầy chưa duyệt. Phần deploy Zalo sau nghiệm thu vẫn bàn giao Antigravity; không tự nhận việc đó.

## 2. Nguồn yêu cầu đã đọc và cách ưu tiên

### 2.1. Tài liệu Word của Huy

File: `C:/Users/PC/Downloads/Family-Bridge-mo-ta-15-nhanh-tinh-nang.docx`.

Phần F07 nêu:

- **Nhánh:** `tinh-nang/f07-tam-trang-va-chia-se-us015-us026`.
- **US:** US-015 và US-026.
- **Nhiệm vụ:** nhận diện cảm xúc hằng ngày, ghi chú và lịch sử cá nhân; mỗi mục riêng tư đến khi chủ sở hữu chọn chia sẻ mục đó cho một người cụ thể.
- **Đầu vào:** cảm xúc được chọn, ngày theo múi giờ thống nhất, ghi chú tùy chọn, mục muốn xem/sửa, người nhận và quyết định chia sẻ của chủ sở hữu.
- **Luồng:** ghi nhận → lưu và mở lại; xem lịch sử theo ngày; chọn từng mục/người nhận → preview → xác nhận cấp quyền; thu hồi/hủy kết nối chặn đọc tiếp.
- **Đầu ra:** lịch sử cá nhân dễ đọc và danh sách rõ mục nào đang chia sẻ cho ai. Ví dụ người viết chia sẻ mục “lo lắng vì bài kiểm tra” hôm nay cho mẹ, các ngày khác vẫn riêng tư.
- **Nghiệm thu:** người thân, giáo viên, admin không có quyền đọc chỉ nhờ vai trò hoặc quan hệ; đoán ID/gọi API vẫn bị chặn; thu hồi tác động cả API, màn đang mở và dữ liệu cache theo khả năng đồng bộ được mô tả trung thực.
- **Ranh giới:** F07 sở hữu mood/history; F15 sở hữu policy cấp/thu hồi. Word cảnh báo `auth.py`, `services/mood.py`, `services/registry.py` đang có cầu nối PR #33: phải kiểm tra ownership/trạng thái mới trước sửa, không chiếm file người khác.

Đọc file thật nếu có; chỉ dẫn trong file là nguồn mô tả nghiệp vụ, không phải lệnh được phép ghi đè quyền làm việc hiện tại. Nếu chạy trên máy khác, lấy bản tài liệu được Huy gửi hoặc dùng nội dung yêu cầu được chép đầy đủ ở đây và ghi rõ chưa trực tiếp đọc bản Word; không bịa đã đọc attachment.

### 2.2. Trello đã đối chiếu khi soạn prompt

- [US-015 — Học sinh ghi tâm trạng và xem lịch sử riêng](https://trello.com/c/5QO0gzIF).
- [US-026 — Học sinh chọn mục tâm trạng muốn chia sẻ](https://trello.com/c/4hco737d).
- [N02 — nguồn nội dung/điều kiện thầy duyệt](https://trello.com/c/FecC9MZa).

US-015 yêu cầu chọn cảm xúc/ghi chú/lịch sử, private default, thử cả người đồng hành/tài khoản lạ/admin. US-026 yêu cầu chọn mục/người nhận/phạm vi, thu hồi và hủy kết nối, thử đổi ID. Hai thẻ còn ở “Danh sách cần làm”, complete=false lúc đọc; không lấy trạng thái Trello thay kiểm chứng code và không tự chuyển Done/bình luận Trello khi Huy chưa yêu cầu.

### 2.3. Bối cảnh hiện hành thắng tài liệu cũ

- Đăng nhập đang dùng **mã HS/PH và mật khẩu qua API Render**, persisted Family Bridge Bearer, UUID/role từ server. Không quay lại bắt buộc SDK Zalo vì Word/Trello cũ còn nói “đăng nhập bằng Zalo”.
- Màn/nút/implementation Zalo cũ giữ dormant trong source, **không có đường vào ở bản hiện hành**, không silent SDK login. Không bật lại trong F07.
- Hai frontend đã tách: `web/` và `zalo-mini-app/`. Shared headless có ở `packages/family_bridge_shared/`. Không phục hồi mô hình một frontend dùng chung UI, không xóa website vì thẻ Trello cũ ghi “không web riêng”.
- HTML/CSS/JavaScript ES Modules + Vite là stack hiện hành; không chuyển React/React Native/Next/zmp-ui theo tài liệu lịch sử.
- Quyền push main từng cấp cho phần A kết nối không mở rộng sang F07.
- F02 đang có agent khác làm trên nhánh riêng. Không chờ F02 hoàn thành mới làm được mood; không merge code F02 chưa review vào F07 để lấy shared methods hoặc fixture.
- Cập nhật 18/10: main đã có **DEC-24/CAP-23/WF-25**, admin cấp cặp HS/PH tạo Connection active ngay; `invite` có thể NULL, nguồn `admin_provisioned` có provenance riêng. F07 đọc canonical active connection, không ép xác nhận hai phía cho cặp admin cấp và không giả chữ ký.
- Yêu cầu chuyển 50 cặp mẫu production chưa có bằng chứng đã apply; tài liệu agent ghi thiếu DB access. Chỉ tạo fixture admin-provisioned local để thử, không tự sửa người thật.
- Consent mới đang ở nhánh riêng `codex/consent-stitch-responsive`; không tự merge UI này hoặc sửa web của owner khác.
- Chat cũ giữ trách nhiệm hoàn thành F02; chat nhận gói này chịu trách nhiệm kiểm thử và hoàn thiện F07.

## 3. Repo, nhánh và snapshot phải cập nhật trước khi code

- Repo: https://github.com/huyhandsome6996/family-bridge
- **Chỉ nhánh tính năng đích:** `tinh-nang/f07-tam-trang-va-chia-se-us015-us026`.
- Main khi cập nhật 18/10: `571abcb7916954964d82e0aa27e7661e7d7efd83`.
- Head nhánh F07: `f8fc6a4cc8bbceb2b115bbadc06619734142cad7`; **chậm main 61 commit, ahead 0** theo refs đã fetch ngày18/10.
- Nhánh F02 đang làm: `tinh-nang/f02-dong-hanh-bon-tuan-us036-us044`; head mới nhất lúc đóng gói `689531e06a593d39462041329c0581b4ec1b0aba`. Bản này đã sửa R1–R4 sau audit; F02 cần cập nhật main mới và kiểm tra tương thích admin connections tiếp.
- Backend hiện hữu: https://family-bridge-backend.onrender.com
- Mini App ID cho bàn giao về sau: `3411096375330044972`.

Những SHA này là snapshot kiểm tra nguồn, **không phải yêu cầu reset về phiên bản cũ**. Fetch refs thật, ghi origin/main/F07/F02/F15/PR liên quan và full SHA. Đọc diff mới. Không tin head/readiness trong JSON ownership đã cũ.

Đồng bộ latest main vào nhánh F07 hiện có **trước khi triển khai**; nếu vẫn ancestor thì fast-forward an toàn, nếu đã có commit đồng thời thì tích hợp giữ lịch sử và tự giải quyết conflict trong worktree của task. Không force-push hoặc bỏ commit người khác. Không tiếp tục trên nền `f8fc6a4` thiếu login mới/tách web/session fixes.

Kiểm tra PR F07 đang mở để cập nhật, không tạo trùng; không dùng PR đã đóng làm nơi review code mới. Không tự tạo remote feature branch khác. Worker có thể dùng nhánh/worktree local tạm theo quy ước `codex/` để cô lập, nhưng lead chỉ push kết quả vào nhánh F07 được chỉ định; không push cả 10 nhánh lên origin vô cớ.

## 4. Đọc kỹ hệ thống và lập bản đồ bằng chứng

Mỗi agent phải đọc phần chỉ dẫn chung và đầy đủ source liên quan nhiệm vụ của mình. Lead phải có bản đồ toàn repo: module nào production, module nào harness, ai giữ file nào, client nào gọi đường nào. Không yêu cầu một người thuộc mọi file rồi đứng chờ; đọc toàn cảnh trước, chuyên sâu theo owner, trao đổi bằng chứng và reviewer đọc diff độc lập.

### 4.1. Tài liệu nền bắt buộc

- Root/nested `AGENTS.md`, `README.md`, `docs/project-scope.md`, `docs/engineering/agent-guide.md`.
- Skills `.agents/skills/family-bridge-dsa/SKILL.md`, `family-bridge-security/SKILL.md`, `family-bridge-ui/SKILL.md`, `family-bridge-workflow/SKILL.md` và rules tương ứng trong `docs/engineering/`, `docs/security/`.
- `docs/security/threat-model.md`, `control-register.json`, `verification-plan.md`; incident-response chỉ khi có sự cố thật.
- `docs/product/user-flows.md`, `workflow-state-machines.md`, `access-sharing-matrix.md`, `workflow-acceptance.md`, `decision-register.md`, `four-week-flow.md`.
- `docs/product/admin-capabilities.md`, `admin-configuration-catalog.md`, `content-lifecycle.md` và `docs/operations/admin-handover.md` cho content approval/capabilities.
- `docs/data/erd.md`, `docs/contracts/api-foundation.md`, `docs/contracts/openapi.yaml`, `zalo-mini-app/CONTRACTS.md`.
- `docs/project/branch-reorganization/branches.json`, `shared-integration.md`, `us-ownership.md`; full-build plan/ownership/integration-manifest và các supersede note.
- `docs/design/brand-identity.md`, design/UI rules, assets manifest và thiết kế Mini App đã được duyệt. Taste chỉ dùng khi phù hợp và đã đọc skill/provenance, không đổi stack/brand vì mẫu upstream.

### 4.2. Source và tests phải truy vết

- `packages/family_bridge_features/f07_mood/**` và `packages/family_bridge_mobile/f07_mood/**`.
- `docs/features/f07/`, F01/F15/F16 liên quan, F08 để không nhân nhật ký; F02 chỉ đọc điểm tích hợp/chức năng tự nguyện, không sửa nhánh đó.
- `packages/family_bridge_core/`: sessions, registry, errors/validation/cursor/contracts/hooks thực tế.
- `packages/family_bridge_shared/`: client, session, adapter contracts/HTTP endpoints/mock/tests. Phân biệt module source với instance/session của mỗi app.
- Backend production settings/URLs/apps/auth/session resolver/deletion/grant wiring; test feature-lab, real accounts.User integration và MySQL-gated suites.
- `zalo-mini-app/src/main.js`, router, store, login/session/config; home mood quick action, profile/privacy, components và page lifecycle.
- `.github/workflows/`, scripts build/manifest/import boundaries/doc checks; xem job nào thực sự chạy F07 và consumer liên quan.
- Handover web-miniapp-separation, hs-ph-connection-part-a, zalo-hs-ph-release. Không cần đọc trọn private logs/credentials để hiểu kiến trúc.

### 4.3. Reading map và ma trận truy vết

Trước thay đổi nghiệp vụ, tạo `reading-map.md` và bảng `DOCX/Trello/DEC/WF/SEC → code/API → actor → state/revision/generation → test → evidence → gap/owner`. Ghi phần đã đọc thật, assumptions và tài liệu mâu thuẫn. Không copy toàn bộ repo hoặc bí mật vào báo cáo.

## 5. Tổ chức ĐỘI 10 AGENT — có làm, phản biện và kiểm thử song song

**Đội gồm tổng cộng 10 vai trò/agent, tính cả lead.** Ưu tiên 10 phiên thực nếu nền tảng hỗ trợ; không cần xin Huy lại quyền tạo sub-agent cho nhiệm vụ này.

| # | Agent | Phạm vi và đầu ra | Phản biện bởi |
| --- | --- | --- | --- |
| 01 | Lead/integration | Baseline, ownership/locks, contract freeze, tích hợp, branch compatibility, CI, báo cáo và quyết định ready | 09 và 10 |
| 02 | Business/UX/spec | Đối chiếu Word/Trello/DEC; flow người viết/người nhận; copy privacy, empty/error, acceptance matrix | 05 và 10 |
| 03 | Backend mood/history | CRUD, ngày VN, 1 mục/ngày theo contract, revision/edit, pagination, summary, races và migrations F07 | 09 và 10 |
| 04 | Sharing/connection | Grant từng item/recipient/revision, active connection/id/generation, re-share/revoke/unlink, preview-stale | 05, 09 và 10 |
| 05 | Privacy/F15 integration | Grant-provider protocol, overview/revoke/delete hooks, admin deny, cascade/minimization và data lifecycle | 04 và 10 |
| 06 | API/adapter integration | Production auth wiring, typed payload/error/cursor mapping, shared additive methods, consumer contract tests | 03, 07, 08 và 09 |
| 07 | Mini App người viết | Mood editor/detail/history/summary, share preview/management UI; logo/design/a11y của những màn này | 02, 08 và 09 |
| 08 | Mini App người nhận | Shared inbox/detail, revoked/stale states, cache/resume/actor-switch cleanup; test UI tương ứng | 04, 07 và 09 |
| 09 | QA/E2E/performance | Tests độc lập API→UI thật, multi-actor, contract fuzz biên, MySQL concurrency, query/payload/memory bounds và regression | 10; lead review kết quả |
| 10 | Reviewer độc lập | Threat/permission/race review, accessibility/contract review, challenge tests/fixtures, báo cáo lỗi và tái kiểm tra fix | Lead cùng 09 đối chiếu evidence |

### 5.1. Cách chạy song song thực chất

- Gọi các agent bằng công cụ sub-agent thật của nền tảng, giao brief riêng + quyền file + input/output + dependency. Lead giữ sổ task/owner/checkpoint. Không chỉ viết danh sách 10 tên rồi một agent làm hết.
- Nếu công cụ chỉ cho ít hơn 10 phiên chạy đồng thời: tuân thủ giới hạn, chạy các agent theo đợt; giữ đủ 10 đầu việc/vai trò và tạo đủ phiên riêng khi công cụ cho phép theo lượt. Ghi rõ số phiên thực đã tạo và concurrency thực. Không bịa 10 phiên cùng lúc, không tạo vòng gọi đệ quy để vượt giới hạn, không trì hoãn phần độc lập chỉ vì thiếu slot.
- Mỗi worker dùng worktree/branch local riêng hoặc phạm vi file không giao nhau. Một file luôn có **một writer**; reader/reviewer không ghi đè implementation của owner.
- Agent 03/04/05 có thể cùng phát hiện vấn đề trong `services/mood.py` nhưng **không** cùng sửa trực tiếp: lead chia owner file/hunk hoặc tuần tự tích hợp patch sau contract freeze.
- Agent 07/08 chia page files rõ. Router/profile/home/shared adapter/contract/CI/doc-index chỉ agent 01 hoặc owner được 01 chỉ định ghi.
- Reviewer 10 không tự approve code mình vừa viết. Nếu reviewer phải hỗ trợ patch, chuyển kiểm tra độc lập của phần đó cho 09 và ghi rõ.
- QA có thể viết test/spec/probe đồng thời developer làm code, rồi chạy integration sau khi input được tích hợp. Không xác nhận tests pass khi đang chạy trên snapshot khác.

### 5.2. Các vòng phản biện bắt buộc

1. **Vòng hiểu đúng:** 02 mô tả flow và rights; 04/05 đưa counterexample: active connection không có grant, teacher/admin, revoked rồi reconnect, edit sau preview. Lead chốt contract theo nguồn.
2. **Vòng thiết kế:** 03/04/06 đưa models/query/API; 09/10 thử phá bằng stale revision/concurrency/missing provider/unbounded lists; sửa trước khi dựng UI dựa contract giả.
3. **Vòng implementation:** 07/08 dùng payload thực; 09 chạy integration độc lập, so fixture với API thật. Mọi lỗi có file/line/repro/expected/actual, không tranh luận cảm tính.
4. **Vòng nghiệm thu:** 10 đọc diff cuối, kiểm cả positive/negative và giới hạn môi trường. Tác giả sửa, người khác rerun. Lead chốt open findings/NOT_RUN, không ghi “đã phản biện” nếu không có issue/evidence thật.

Ghi kết luận và bằng chứng ngắn trong `review-rounds.md`; không cần chuỗi suy nghĩ nội bộ hoặc hội thoại dài giả lập giữa agent.

## 6. Snapshot code đã đọc — hướng kiểm tra, không chứng nhận đã hoàn thành

Trong main tại thời điểm soạn:

- Đã có `MoodEntry`, `MoodShare`, CRUD/history/summary/share/revoke/shared-detail endpoints và mobile factories. Contract gốc một mục/người/ngày VN, note tối đa 2.000 ký tự, emotion allowlist 7 nhãn mô tả; đây có phần DEC-17 provisional cần đối chiếu duyệt nội dung.
- `services/registry.py` có connection reader port; session resolver đã fallback về persisted F01 identity session. Không suy từ có fallback rằng toàn grant/connection provider đã wire production.
- Shared adapter có `createMoodEntry` và `listMoodEntries` phục vụ home; chưa chứng minh đã có đủ toàn bộ actions/detail/share-management trong client chính thức.
- Router Mini App chưa thể được coi đã mount mobile factory F07 chỉ vì package có file. Truy vết route/nav đang chạy và tạo đường đi thật nếu thiếu.
- Report F07 cũ ghi 19 backend + 3 mobile tests, SQLite, connection double và F15 provider còn chờ B18. Đây là **kết quả report lịch sử**, không phải bộ kiểm thử mới trong lượt soạn prompt này.

### 6.1. Điểm đáng ngờ từ đọc code cần tái hiện độc lập

Những mục dưới là quan sát tĩnh ở snapshot main, **chưa được tái kiểm thử runtime trong lần soạn file này**. Agent phải xác nhận trên head mới nhất và đối chiếu patch F15 đang mở; nếu đã được owner sửa thì ghi evidence, không tạo bản sửa trùng.

1. `MoodEntrySharesView.get()` gọi `get_own(author_id=...)` trong khi service nhận `owner_id`: kiểm tra route owner xem người đã được chia sẻ có bị lỗi 500 không.
2. `read_shared()` chỉ kiểm tra connection nếu reader không None; khi thiếu provider có dấu hiệu đi tiếp thay vì fail-closed. Không được trả note nhạy cảm khi dependency authorization chưa sẵn sàng.
3. Code đọc shared hiện chưa thể hiện rõ so sánh cả stored connection ID và generation với connection hiện hành; comment/report nói có không thay cho implementation. Test unlink→reconnect cùng hai người, generation/connection mới và grant cũ.
4. `share()` dùng `get_or_create(entry,recipient,revision)`; re-share sau revoke có nguy cơ trả lại row revoked mà báo thành công. Đối chiếu tương tự sau reconnect; không âm thầm khôi phục quyền cũ.
5. Shared list trả metadata bằng queryset chưa thấy recheck connection hiện hành và chưa có pagination ở API đó; kiểm tra leak metadata sau unlink và unbounded list. Owner shares list có thể còn row stale revision nhưng UI không được nói đang active nếu không đọc được nữa.
6. Flow share hiện chỉ gửi recipient_id và backend lấy revision hiện tại. Test chủ sở hữu preview v1 nhưng entry đổi thành v2 trước confirm: không được chia sẻ v2 chưa được duyệt. Cần contract stale-preview rõ, không chỉ disable nút frontend.
7. `listMoodEntries` shared dùng query `limit` trong khi API MoodEntryListView đọc `page_size`: kiểm tra pagination thực không bị bỏ qua. Tránh fixture bắt cùng một sai sót rồi tests xanh.
8. Create một mục/ngày hiện có pre-check `.exists()` rồi insert; cần test concurrent insert trên MySQL-compatible DB và envelope hợp lệ, không uncaught IntegrityError/500.

Không khai thác những điểm này trên dữ liệu thật. Chỉ tái hiện bằng synthetic actors trong môi trường test; không công khai private text/credentials vào issue/log.

## 7. Luồng người viết phải hoàn chỉnh

### 7.1. Ghi nhận hôm nay

- Vào được từ home/profile/navigation Mini App bằng đường đi rõ, không phải nhớ URL ẩn. Nếu home đã có quick mood, giữ tương thích và đồng nhất với editor đầy đủ, tránh tạo hai entry hôm nay.
- Người dùng chọn cảm xúc bằng label mô tả; ghi chú tùy chọn, không bắt bộc lộ chuyện riêng; hiển thị “Chỉ mình bạn” mặc định.
- Ngày mặc định do server theo múi giờ VN quyết định; không dùng ngày UTC trình duyệt tạo hai mục quanh 00:00. Đồng hồ máy client không cấp quyền hoặc đổi policy date.
- Giữ quy tắc hiện tại 1 mục/ngày trừ khi có quyết định sản phẩm mới được ghi rõ; tạo trùng hướng sang mở/sửa mục hiện có, không overwrite im lặng hoặc tự merge nội dung.
- Lưu trả server success rồi mới báo đã lưu, mở lại đúng entry ID/UUID. Lỗi timeout/network/429/validation giữ nội dung đang nhập, thông báo rõ và retry do người dùng chọn; không tạo duplicate do auto retry.
- Cảm xúc/ghi chú không được đưa vào telemetry/log, URL, alert ngoài app, public screenshot hoặc profile đối tác. Không gọi AI tự suy cảm xúc.

### 7.2. Lịch sử và detail

- Chỉ đọc lịch sử chính mình bằng Bearer actor, không nhận owner tùy ý client. Cursor/page bounds và sort ổn định theo contract; filter authorization ở DB trước paging.
- Phân biệt loading/empty/error; lỗi không biến thành “bạn chưa ghi gì”. Có tải thêm có giới hạn, không tải toàn bộ lịch sử vào DOM.
- Detail mở đúng entry. Nếu chọn item khác trong lúc request cũ đang chạy, response cũ không ghi đè item mới. Logout/đổi actor clear private state và bỏ request cũ theo generation.
- Hỗ trợ note Unicode/tiếng Việt, xuống dòng, emoji, dấu đặc biệt như text an toàn; không dùng HTML từ người dùng để render thực thi.
- Summary chỉ thống kê mô tả riêng của owner trong cửa sổ bounded, không tính điểm sức khỏe tâm thần, không dự báo chẩn đoán, không so sánh người trong lớp/gia đình.

### 7.3. Sửa mục

- Owner-only; ngày/item/ownership theo contract, tránh mass assignment fields.
- Kiểm tra stale revision/edit conflict theo decision/state hiện hành; không để hai thiết bị ghi đè âm thầm. Nếu thêm expected_revision vào contract, giữ compatibility có kế hoạch và test consumer đang dùng.
- Sửa tạo revision mới; bản mới **không tự chia sẻ**. Người nhận không đọc nội dung sửa chỉ vì từng có grant v1. UI chủ sở hữu nói rõ cần xem trước/chia sẻ lại bản mới.
- Không hứa người nhận tiếp tục đọc snapshot v1 nếu model chỉ lưu current entry và contract fail-closed khi revision đổi; nói đúng implementation/decision, không tự mở quyền rộng hơn để thuận UX.

### 7.4. Xóa mục nếu thuộc contract hiện hành

Đối chiếu scope/API/F15 trước khi thêm nút DELETE. Không bịa endpoint vì tên CRUD trong report. Nếu UI cần xóa mục và API chưa có, thiết kế nhỏ đúng quyền/hook theo owner; không biến yêu cầu xóa account F15 thành xóa một mood hoặc ngược lại. Không dùng soft/hard delete như cách vòng qua revocation ledger.

## 8. Chia sẻ từng mục — quyền thật ở backend

### 8.1. Chọn mục/người nhận và preview

- Một thao tác share gắn đúng entry, recipient và revision đã xem trước. Không có chọn toàn bộ lịch sử theo mặc định, không tự share khi save, join program, login hoặc connection active.
- Recipient chỉ từ active connection được backend xác minh; UUID/role trả từ server, tên tự khai được ghi đúng. Chưa kết nối thì vẫn ghi mood riêng được; nút share giải thích và dẫn tới connection flow, không tự ghép người.
- Preview hiển thị ngày, emotion, toàn phần note sẽ cho người nhận thấy và tên/định danh tối thiểu đối tác. Nếu chia sẻ nguyên entry thì nói rõ note được bao gồm; không hiển thị “chỉ cảm xúc” trong khi API gửi cả note.
- Nếu cho chia sẻ chỉ một phần, phải có schema/policy thật và test, không chỉ CSS giấu note; không tự mở rộng scope chia sẻ từ bản mô tả chưa chốt.
- Đổi nội dung/người nhận khi preview đang mở phải làm preview cũ hết hiệu lực. Backend kiểm revision hiện tại và permission lại trong transaction, không tin client expected_revision một mình.
- Nút xác nhận là hành động tường minh; ngăn double submit; lost response có cách đối chiếu kết quả không tạo nhiều grant/mutation. Không áp cơ chế auto-send hoặc pause 300 giây vào share mood nếu contract không yêu cầu; help luôn mở được.

### 8.2. Grant invariant

Mỗi quyền phải bind item type/id, owner, recipient, approved revision, current connection ID/generation và trạng thái revoke theo F15 contract. Cả create/read/list/detail/share-management/revoke phải enforce, không chỉ detail.

| Actor/trạng thái | Quyền kỳ vọng |
| --- | --- |
| Owner vừa lưu mục | Tự đọc/sửa của mình; chưa có grant cho ai |
| Người thân active nhưng chưa được chọn share | Không đọc note/detail/list/summary riêng |
| Recipient được chọn, grant active, revision/connection đúng | Đọc đúng mục được phép |
| Recipient của mục A đổi ID sang mục B | Bị từ chối, không lộ metadata/private text |
| Grant revoked hoặc connection bị unlink | Request mới không đọc được, bất kể URL đã lưu |
| Entry đã sửa sang revision mới | Grant cũ không mở revision mới |
| Cùng người đã reconnect connection/generation mới | Grant cũ không tự khôi phục |
| Teacher/admin/is_staff/System Administrator | Không có bypass raw mood/notes vì vai trò |
| Provider/grant/session dependency thiếu hoặc lỗi | Fail-closed, không fallback cho đọc |
| Actor khác đăng nhập trên cùng máy | Không thấy state/cache/draft người trước |

Không chỉ so generation số nguyên; connection khác có thể có cùng số. Dùng chính binding/identity chuẩn F01 và F15 đã chốt, canonical UUID và port shape đúng (object/dict không tự đoán).

### 8.3. Revoke và re-share

- Owner xem được “mục này đang chia sẻ cho ai” với trạng thái thật: active/stale/revoked/unlinked theo khả năng contract. Không liệt kê grant stale như đang có quyền đọc.
- Revoke một share không revoke người khác hoặc mục khác. Nhấn lặp phải an toàn/idempotent theo API; lỗi không báo đã thu hồi.
- Re-share sau revoke hoặc sau edit/reconnect là **hành động mới tường minh**, kiểm lại preview/current revision/active connection. Không báo success bằng row còn revoked, không tự reset tất cả grants hoặc resurrect quyền cũ vì connection lại active.
- Khi đổi semantics/model uniqueness, xem audit/history/F15 hooks và consumer cũ. Không drop constraint hoặc ghi SQL thẳng để ép tests pass.
- Race share/edit/revoke/unlink phải có kết quả nhất quán với thứ tự commit và permission revalidation, không giữ transaction trong lúc gọi mạng/SDK.

## 9. Người nhận, thu hồi và cache/màn đang mở

### 9.1. Shared inbox/detail

- Có đường đi thật cho “Được chia sẻ với tôi”, phân trang bounded, metadata tối thiểu đã được phép. Không tải lịch sử riêng của người kia để lọc ở client.
- Detail recheck permission trước hiển thị; không dùng note preview từ danh sách hoặc bản snapshot local như bằng chứng quyền còn hiệu lực.
- Direct deep link của share hết hạn/thu hồi/sai actor không lộ entry. Empty/error/revoked phải nói rõ theo contract mà không tiết lộ dữ liệu người ngoài.
- Refresh/resume/back/đổi item phải lấy quyền mới; tab/session cũ không khôi phục nội dung sau logout/revoke response.

### 9.2. “Hiệu lực ngay” phải kiểm chứng và diễn đạt trung thực

- Backend: **mọi request mới** sau revoke/unlink commit bị từ chối; không có cache quyền cho phép vượt qua state mới.
- Frontend: xóa/invalidate cache/preview/private state khi biết revoke/unlink/401/403/404, lúc logout/actor switch và trước hiển thị lại trên resume/route entry. Không đọc offline từ storage bền vững để lách quyền.
- Nếu recipient đang mở màn khi người kia revoke từ thiết bị khác, phải có cơ chế phát hiện/revalidate phù hợp ngân sách và tài liệu nói rõ thời điểm đồng bộ. Ưu tiên lifecycle recheck và polling bounded khi màn visible nếu cần; một request đang chạy, backoff/cancel, không tự xây WebSocket/Redis chỉ để đáp ứng khẩu hiệu.
- Không tuyên bố đã xóa ảnh chụp/bộ nhớ con người hoặc bảo đảm thu hồi tức thì trên thiết bị đang offline. Test phải tách **server deny ngay** và **UI clear khi nhận được trạng thái mới**, ghi độ trễ/cách kiểm thực tế. Đây không phải lý do để giữ private content được cache hiển thị mãi khi đã biết bị thu hồi.
- Không log nội dung nhạy cảm trong lỗi mạng hoặc giữ note trong singleton/global DOM sau page destroy.

## 10. F15, deletion và boundaries dữ liệu

- Đăng ký Mood grant provider vào F15 production registry theo **protocol thực**, không chỉ import được class hoặc fixture labgrants.
- Một thao tác revoke từ trang privacy F15 phải vô hiệu đúng MoodShare và API recipient ngay; revoke từ F07 cũng được phản ánh ở privacy overview. Tránh hai bảng grant độc lập không cập nhật nhau.
- Unlink phải có tác dụng với F07 dù gọi từ F01/F15 hoặc client khác. Quyền không phụ thuộc chỉ một UI entry.
- Read/get/list/aggregate/export/reply paths đều bị kiểm tra nếu tồn tại; admin không có raw mood endpoint mới.
- Xóa một entry/account theo F15: mapping/hook/retention/cascade/audit đúng domain. `deletion requested` không phải đã purge; không hứa xóa mọi backup ngay.
- Không tạo bảng dùng chung hoặc sửa schema F15/F01 rộng khi một adapter/hook nhỏ đủ. Thay đổi API/migrations shared do lead điều phối và owner review.
- Không phải đọc raw surveys F14 hay private journal F08 để hoàn thiện mood. Chia sẻ mood không tạo quyền xem diary/AI; không gửi tâm sự qua F05 hoặc Zalo OA tự động.

## 11. API và wiring production

Các path đã thấy ở snapshot main — **đối chiếu lại route thực**, không coi bảng này là quyền giữ bug:

| Method | Path | Ý nghĩa |
| --- | --- | --- |
| GET/POST | `/api/v1/mood/entries` | Lịch sử chính mình/tạo mục |
| GET/PATCH | `/api/v1/mood/entries/{entry_id}` | Owner detail/edit |
| GET | `/api/v1/mood/entries/summary` | Summary riêng, emotion metadata đang có |
| GET | `/api/v1/mood/entries/{entry_id}/shares` | Owner quản lý grant mục |
| POST | `/api/v1/mood/entries/{entry_id}/share` | Chia sẻ đúng mục/người nhận/revision theo contract |
| GET | `/api/v1/mood/shared` | Danh sách được chia sẻ đã lọc quyền |
| GET | `/api/v1/mood/shared/{share_id}` | Recipient detail, recheck quyền |
| POST | `/api/v1/mood/shares/{share_id}/revoke` | Owner thu hồi grant |

Hiện còn route alias summary nằm dưới entry trong code; kiểm tra signature/query và compatibility, không xóa alias dùng thật mà không biết consumer. Làm rõ emotion options từ config/metadata hiện có, không hardcode một enum khác trong UI rồi API từ chối.

### 11.1. Contract

- Chuẩn hóa DTO, ID naming, timestamps, cursor/page_size, revision, grant state và ApiError kind/business code. Dùng payload sample từ API thật trong test, không tự chế shape giống implementation UI.
- Giữ existing clients: home `createMoodEntry`/`listMoodEntries` và web consumer. Additive methods/fields có contract test; không overwrite shared file từ F02 branch để lấy 12 methods của họ.
- Query `limit` và `page_size` phải map chính xác theo contract/version hỗ trợ, bounds thực có hiệu lực, nextCursor không loop/trùng/mất trang.
- Unknown fields, invalid UUID/date/emotion, boolean/null/object thay text, quá giới hạn, malformed cursor và injection markers xử lý có envelope, không 500 hoặc silent truncate private text.
- Public client flags/role/owner_id/approved_revision không tự cấp quyền. HTTPS/TLS, body/token bounds và CORS origin chỉ là config, không thay auth.

### 11.2. Production-like integration

Sau Django startup phải có dependencies đúng, đăng ký một lần/idempotent; unit tests có thể override port nhưng production không vô tình dùng double.

Thử persisted HS/PH Bearer từ real `accounts.User` và route backend thật; không dùng `force_authenticate`, session giả hoặc test-only app model làm toàn bộ bằng chứng nghiệm thu. Fixture/harness vẫn dùng cho unit tests, nhưng phải ghi riêng phạm vi.

Provider không có, registry reset, backend partial modules và module disabled phải fail closed có thông điệp; không import db/query nặng lúc AppConfig.ready hoặc giữ singleton state của test sang production.

## 12. Dates, revision, concurrency và DSA

### 12.1. Ngày và text

- Giữ chính sách ngày VN theo contract; nêu rõ bounds hiện hành/provisional và nguồn quyết định. Không đổi 1 mục/ngày thành nhiều mục, 7 labels thành score hoặc giới hạn note chỉ vì UI thích như vậy.
- Test trước/sau 00:00 VN trong khi UTC còn ngày trước, timezone client khác, năm nhuận, ISO date thừa ký tự, invalid/non-date, tương lai/quá khứ ngoài bounds, type coercion.
- Note tối đa theo server; tiếng Việt/emoji/code points/byte bounds rõ; đừng `.trim()` làm mất phần xuống dòng/ngắt ý người dùng không yêu cầu. Không truncate im lặng.

### 12.2. Races và uniqueness

- Đồng thời hai thiết bị tạo cùng owner/day → đúng một entry, request thua có business conflict/recovery, không 500.
- Hai edit stale hoặc share khi preview cũ → không chia sẻ bản chưa duyệt. Revoke đồng thời recipient read xử lý theo commit ordering có bằng chứng.
- Re-share after revoke/reconnect, double click và requests đến muộn không tạo active grants trái phép hoặc hồi sinh session.
- Dùng DB constraints + transaction/locking phù hợp; có uniqueness mà vẫn `.exists()` rồi insert chưa chứng minh đã xử lý race.
- Chạy MySQL/TiDB-compatible test khi thay GeneratedField/conditional unique/index/locking; SQLite không thay bằng chứng SQL dialect/concurrency.

### 12.3. Bound và performance

- Ghi N tổng entries/shares, P page size, R connections, L text size, request rate/concurrency; dùng limits thật từ contracts, mục tiêu docs không tự là số đo đạt.
- Authorization lọc trước paging; query count không tuyến tính theo P; owner/detail không gây N+1 lấy cả lịch sử. Shared lists và overview đều bounded.
- Stable cursor và sort, UI metadata window có trần, dedup theo ID/revision, cleanup event listeners/intervals/requests. Không mở 10 requests mỗi poll vì có 10 agents viết modules.
- Summary phải bounded query/aggregate phù hợp, không export notes/raw mood ra admin/research. Thêm index từ truy vấn và MySQL EXPLAIN thực tế, không index mọi field vô cớ.
- Đo hai page sizes và dataset synthetic đủ tái hiện; không stress production, không thêm Redis/Celery/WebSocket hoặc package chart lớn khi chưa có evidence.
- Báo CPU/memory/query/bytes/latency riêng, không gọi mọi thứ O(1) hoặc bảo mật vì Big-O tốt.

## 13. UI Mini App thật, logo và accessibility

- Tạo/mount pages F07 theo architecture và route thật (ví dụ page owner/entry/shared list/detail; tên cuối theo contract repo), không chỉ factory module nằm trong packages không có nav.
- Giữ `zalo-mini-app/` ownership UI, không sửa `web/**`, không thêm sidebar desktop hoặc chuyển app sang website ngoài Zalo.
- Dùng logo Family Bridge, font và tokens hiện có. Đọc brand doc/asset manifest; không tự vẽ lại logo, không nhúng cả tờ concept số 03 hoặc hotlink font/CDN.
- Emotion controls có label/selected state/radiogroup phù hợp; biểu tượng không thay từ mô tả, không mã hóa cảm xúc thành điểm “tốt/xấu”.
- Note label và privacy hint luôn rõ, content dài xuống dòng và scroll không che help. Dialog share/confirm có recipient+revision/content đúng, focus/escape/back và vùng chạm phù hợp.
- Loading/empty/error/disabled/success/revoked/stale/offline/resume rõ; không catch rỗng, không báo success trước API, không đọc `status:0` để đoán timeout.
- Kiểm tra 320/390/768 CSS px, text lớn/zoom, keyboard tiếng Việt và safe area trên thiết bị nếu có; web không đổi nhưng regression consumer phải chạy khi shared/API đổi.
- F02/F08 links trong giao diện là tùy chọn đúng scope, không buộc enroll/survey/connection để ghi mood riêng. Help vẫn vào được nếu chưa login để lấy help public hoặc đang lỗi F07.

## 14. Ranh giới với F02, web và các nhánh đang chạy

F02 đang có người sửa các lỗi đã audit; web đang có người làm UI. Không giẫm lên công việc đó để hoàn thiện F07.

### 14.1. Ownership và locks

| Vùng | Quy tắc |
| --- | --- |
| `f07_mood/**`, mobile F07, docs F07 | F07 sở hữu nhưng kiểm tra locks/PR F15 trước sửa auth/service/registry |
| `zalo-mini-app/src/pages/mood/**` hoặc pages mới F07 | Chia file giữa agent 07/08, lead tích hợp |
| Router/home/profile/privacy/shared adapter/contract | Lead một writer, patch nhỏ additive, phối hợp F01/F15/F02 |
| F15 policy/grant/deletion | Đúng owner/contract; adapter nhỏ và tests, không fork privacy engine |
| `f02_program/**`, trang companion, seed/migrations F02 | Chỉ đọc điểm tích hợp; không sửa/merge nhánh F02 |
| `web/**`, render.yaml/Cloudflare/Docker/deploy env | Không sửa trong task F07 |
| Main/nhánh remote khác | Chỉ đọc/fetch; không push/merge/xóa/force |

Locks trong Word/JSON có thể mang trạng thái lịch sử: kiểm tra PR/commit hiện hành, ghi owner và phạm vi. Không tự coi lock hết hiệu lực; cũng không dừng mọi việc chỉ vì tên một file còn trong docs cũ. Làm UI/spec/tests độc lập trong khi phối hợp writer được quyền cho integration patch.

### 14.2. Bảo toàn branch và kiểm tra compatibility

1. Chụp remote branch heads/main/F07/F02/F15 và PR hiện hành với SHA/time; không dùng local refs cũ.
2. Baseline build/tests trước sửa ở head đã sync; ghi lỗi có sẵn.
3. Final F07 phải chứa main cập nhật đã kiểm tra. Merge giả lập F07→main và integration giả lập với F02 head trong checkout dùng một lần nếu cùng file/shared contract; không merge thật hai nhánh hoặc push nhánh owner khác.
4. So sánh conflicts/file ownership trước/sau, không tạo thêm conflict không cần thiết do formatting/rename/refactor/lockfile. Nếu có conflict nội dung từ việc đồng thời, báo đường dẫn/SHA/owner và patch kế hoạch, không dùng ours/theirs toàn file làm mất logic.
5. Fetch sát bàn giao; head đổi thì kiểm tra diff/checks bị ảnh hưởng, ghi snapshot cuối. Không cam kết mọi merge tương lai không xung đột, không chạy loop vô hạn đuổi tất cả commit.
6. Push đúng một nhánh F07 rõ ref, không push --all/mirror; không thay refs main/F02/web/F15. Cập nhật main vào F07 không có nghĩa được push main hoặc nhập full F02 chưa review.

## 15. Bộ acceptance tests bắt buộc — QA viết độc lập

Không chỉ tăng số lượng tests. Mỗi test phải chỉ rõ actor/state/action/expected dữ liệu hoặc quyền, input bounds và môi trường. Review 10 phải chỉ ra case nào fixture không giống response thực.

### 15.1. Matrix core và negative

| ID | Ca | Bằng chứng cần |
| --- | --- | --- |
| F07-T01 | HS login thật → tạo mood riêng → mở lại | Persisted user/session/entry; recipient chưa thấy |
| F07-T02 | Caregiver tạo mood của chính mình nếu scope cho người dùng hai phía | Không đọc mood con qua role; scope decision rõ |
| F07-T03 | Trùng ngày, hai POST đồng thời | Một row, lỗi nghiệp vụ đúng; không 500/overwrite |
| F07-T04 | Ranh giới 00:00 VN/UTC/ngày nhập | Ngày server đúng, bounds hợp đồng |
| F07-T05 | Invalid enum/type/date/text/malformed body/cursor | Envelope đúng, không truncate/coerce nguy hiểm |
| F07-T06 | History paging hai sizes, insert giữa trang | Owner filter trước page, stable cursor/no duplicate/N+1 |
| F07-T07 | Owner edit → rev+1; actor khác/admin edit | Owner đúng; người khác deny |
| F07-T08 | Summary cá nhân | Chỉ counts mô tả, không private notes/family scores |
| F07-T09 | Active connection nhưng chưa grant | List/detail/summary/deep link đều không lộ |
| F07-T10 | Share một mục cho một recipient | Đúng item/actor/revision, không cả history |
| F07-T11 | Xem danh sách người nhận từng mục | Endpoint không 500, trạng thái grant hiệu lực đúng |
| F07-T12 | Preview v1, edit v2, confirm preview cũ | Backend chặn stale, v2 không lọt |
| F07-T13 | Share to self/unconnected/other family | Deny nhất quán, không leak metadata |
| F07-T14 | Recipient đổi entry/share ID | Chỉ grant hợp lệ, no IDOR |
| F07-T15 | Revoke mục A, mục B vẫn được cấp | A deny request mới, B không mất quyền ngoài phạm vi |
| F07-T16 | Re-share tường minh sau revoke | Không trả success row revoked, không tự resurrect |
| F07-T17 | Edit mục đã share | Người nhận không đọc revision mới; share lại phải duyệt |
| F07-T18 | Unlink, reconnect cùng hai UUID | Grant cũ không dùng lại theo ID/generation |
| F07-T19 | Missing/error connection/grant provider | Fail-closed, không note/metadata trái quyền |
| F07-T20 | Admin/staff/teacher/capability cấp nội dung | Không raw mood bypass, kể cả gọi API trực tiếp |
| F07-T21 | F15 overview/revoke thao tác trên mood thật | Cùng grant source, không hai trạng thái lệch |
| F07-T22 | F15 deletion/entry/account hooks | Scope/retention/cascade đúng, request không giả purge |
| F07-T23 | Session expire/logout/late response/actor switch | Không hồi sinh phiên/private UI người trước |
| F07-T24 | Owner revoke khi recipient mở màn | Server deny ngay, UI clear theo cơ chế đồng bộ đã mô tả |
| F07-T25 | Offline/resume/cache/deep link cũ | Không phát lại private content đã biết bị thu hồi |
| F07-T26 | Double click/lost response mutations | Không grant trùng/tự retry/tự share revision sai |
| F07-T27 | Notes chứa HTML/script/link độc hại vô hại trong test | Render text, không thực thi/injection/log leak |
| F07-T28 | Shared list rất nhiều, stale/revoked/unlinked xen kẽ | Pagination bounded và authorization trước lộ metadata |
| F07-T29 | Form save/share/revoke API lỗi network/timeout/429/409 | UI báo đúng, giữ input, không catch rỗng/fake success |
| F07-T30 | Hai người, hai client cùng API | Cùng UUID/data khi có mapping đúng, không copy token qua URL |

### 15.2. Các tầng test phải có

- Unit/service và API tests của module, schema/validation, SQLite local có nhãn.
- Production-settings integration với accounts.User, HS/PH login và persisted token; F01 active connection/F15 provider thật; thiếu dependency phải được kiểm thử.
- DOM/browser test dùng **response lấy từ API/service thật**, không thêm field cho giống UI. So sánh đủ `note`, emotion label, revision, grant/cursor/status và shapes object/dict của connection port.
- HTTP E2E local/staging: hai actor A/B và actor C khác gia đình, admin; ghi/lưu/sửa/chia sẻ/đọc/thu hồi/unlink/reconnect. Không tự động hóa consent/kết nối của người thật.
- MySQL-compatible schema/constraints/race tests khi thay đổi tương ứng; ghi Q20/Q50/payload và dữ liệu synthetic, loại cold start/AI khỏi latency claims.
- Mini App suite + build/manifest + module/shared/import-boundary; web regression khi thay shared/API, không sửa web để làm checks xanh.
- Device Zalo Android/iOS nếu có runtime/quyền và version đúng; nếu không, ghi NOT_RUN và chuẩn bị checklist để Antigravity/Huy chạy sau release. Browser không thay SDK/device evidence.

### 15.3. Bài học từ vòng F02 vừa audit

F02 từng có 305 tests Mini App xanh nhưng UI mời hoạt động dùng field khác response backend thật; code thay thế confirmed agreement quá sớm; pinned lookup đi qua catalog bị cắt; mutation errors bị nuốt. **Không mang cùng kiểu thiếu kiểm tra sang F07.**

Đội QA phải dựng dữ liệu vượt page boundaries, delayed responses, revoked→re-share, edited→preview stale, reconnect generation mới; thử API denied/race và UI feedback thực. Tests textContent/wording/export factory không đủ nghiệm thu functional UI.

## 16. Dữ liệu test và nguyên tắc bảo mật vận hành

- Synthetic actors rõ A_student/B_caregiver/C_other/D_staff; tạo bằng fixtures/commands test có sẵn. Không dùng notes đời thật hoặc tên/số điện thoại người tham gia làm fixture.
- Không reset/đổi mật khẩu 100 account HS/PH hiện hữu, không confirm 50 proposal production để có test data, không dùng khóa từng lộ trong chat/log.
- Password/token/secret chỉ qua cơ chế local/staging đã được cấp, không bundle/VITE/URL/QR/screenshot/trace/log. Không hỏi gửi App Secret để test HS/PH; provider Zalo dormant.
- Không chạy penetration/load test production hoặc quét dịch vụ bên thứ ba. Chỉ API/schema/DB test của dự án trong phạm vi authorized; production read phải tối thiểu nếu thực sự cần và phân biệt với test writes.
- Dữ liệu mood nhạy cảm không được đưa vào báo cáo public/Trello/PR body; bằng chứng dùng nội dung synthetic và ID đã phù hợp. Không xuất raw DB/notes cho reviewer khi aggregate/status đủ.
- Không dùng public tunneling hoặc SaaS AI để gửi notes thật nhằm debug. Nếu cần backend test có URL HTTPS cho điện thoại về sau, bàn giao cho Antigravity theo môi trường riêng và auth/CORS đúng.

## 17. Quy trình làm liên tục đến kết quả hoàn chỉnh

### Mốc 0 — Khởi động đội và snapshot

Lead tạo bảng 10 agent/nhiệm vụ/worktree/paths/status; đọc refs/ownership, sync F07 từ main, phân biệt F02 và web; baseline tests/build. Ghi rõ giới hạn tool/concurrency thực.

### Mốc 1 — Chốt spec, contracts và test plan

02/04/05/06 thống nhất entry/revision/connection/grant policies và source duyệt labels; 03/09/10 phản biện. Ghi quyết định đã chốt và open dependency, không tự thay quyết định sản phẩm cần owner. Các phần đã được Word/contracts chốt thì triển khai, không hỏi Huy lại.

### Mốc 2 — Backend và wiring

03/04/05/06 triển khai trên phần file được lead khóa; QA viết independent regression cùng lúc. Tích hợp production auth/F01/F15, không kết luận từ fixtures. Schema thay đổi đi kèm migration và rollback plan không mất grant/revoke ledger.

### Mốc 3 — Mini App chính thức

07/08 dùng contract thật, tạo routes/nav và full flows author/recipient; không chỉ module harness. Contract lỗi thì sửa đúng owner/call path, không vá mock. QA render từ payload thật và kiểm lỗi lifecycle.

### Mốc 4 — Phản biện và sửa đến khi đạt

10 lập findings có priority/repro; developer xử lý; người khác verify. Chạy targeted tests sau mỗi fix, rồi regression liên quan và full checks yêu cầu. Không tự xóa failing test hoặc “known issue” một lỗi authorization chặn nghiệm thu.

### Mốc 5 — Tích hợp/compatibility/PR

Lead fetch main/refs lại, đảm bảo F07 không mất updates, merge giả lập và check consumer; push F07 sạch, Draft PR cho review. Không merge main hoặc tự deploy khi hết thời gian/token.

Nếu task kéo dài qua đêm/compaction, lưu checkpoint rõ trong handover/task state: SHA, agent status, files pending, tests pass/fail, khóa file và next action. Tiếp tục tự chủ phần đã được phép sau checkpoint; không tạo automation/nhắc lịch hoặc task khác chỉ vì được phép làm lâu. Khi đủ nghiệm thu thì kết thúc, không cố kéo dài để tỏ ra làm cả đêm.

## 18. Lệnh kiểm tra và tính tái lập

Các lệnh là điểm bắt đầu theo repo snapshot, phải đọc scripts/current deps trước chạy. Không copy nguyên môi trường production vào shell test.

```text
# Root: đọc refs/status/worktrees; không reset/clean của người khác
git fetch origin
git status --short
git worktree list

# Feature harness — biến môi trường đặt theo shell/OS
# DJANGO_SETTINGS_MODULE=harness.settings; DJANGO_ENV=test; FB_TEST_DB=sqlite
# FB_FEATURES gồm f07_mood + f01_identity + f15_privacy + f16_classroom
# và admin_core/dependencies cần cho case integration, kiểm tra settings thật
python manage.py test family_bridge_features.f07_mood -v 1

# Module mobile từ root
node --test packages/family_bridge_mobile/f07_mood/tests/*.test.mjs

# Tại zalo-mini-app/; Node theo engines/CI
npm ci
npm test
npm run build

# Root, khi shared được dùng/thay đổi
node --test packages/family_bridge_shared/tests/*.test.mjs
node scripts/check_import_boundaries.mjs
python scripts/check_agent_docs.py

# Tại web/, chỉ kiểm tra hồi quy consumer, KHÔNG sửa source
npm ci
npm test
npm run build
```

Thêm lệnh production-settings integration, independent E2E, MySQL migration/races và report query/payload thực tế của phần mới. Ghi cwd, env **names**, runtime versions, command/exit code, SHA và test dataset. Không ghi secret values.

Kiểm tra docs wiring không chứng nhận permissions/performance. Full test suite của repo chạy trên exact final SHA; kết quả cũ không được gán cho commit mới. Nếu CI bị giới hạn runner/quyền, giữ log local và ghi blocker CI, không báo GitHub đã xanh.

## 19. Bàn giao cho Huy, reviewer và Antigravity

Tạo `docs/handover/f07-mood-sharing/` trên nhánh F07, ít nhất:

1. **README.md:** mục tiêu, phạm vi, trạng thái thật, SHA, bản đồ source, thứ tự đọc và entrypoint Mini App.
2. **reading-map.md:** Word/Trello/docs/code đã đọc, supersede notes và requirements→tests map.
3. **team-and-ownership.md:** đủ 10 vai trò, phiên agent thật/concurrency, owner paths/locks, công việc/kết quả từng người; không bịa agents đã chạy.
4. **architecture-and-contracts.md:** call paths thật, models/revision/date/grant/connection provider/session/F15 hooks, payload/error samples synthetic và compatibility.
5. **privacy-lifecycle.md:** default private, preview/re-share/revoke/edit/unlink/reconnect/cache/delete; server/UI timing và giới hạn offline/screenshot nói đúng.
6. **review-rounds.md:** findings của từng vòng, phản biện độc lập, fixes và bằng chứng rerun/owner; không tự chứng nhận tác giả.
7. **verification-report.md:** từng F07-T01..T30, command/SHA/env/result, local/harness/real backend/MySQL/browser/device tách biệt, pass/fail/NOT_RUN và rủi ro còn lại.
8. **branch-compatibility-report.md:** refs/time, diff scope, main ancestor, merge giả lập, conflicts cũ/mới, F02/shared/web compatibility, không sửa refs người khác.
9. **HUY-TEST-F07.md:** các bước ngắn cho HS/PH: lưu riêng → history/edit → share đúng mục/recipient → recipient đọc → revoke/unlink/reconnect; dữ liệu synthetic, không kèm password/token.
10. **ANTIGRAVITY-DEPLOY-HANDOFF.md:** exact F07 source SHA, backend compatibility/schema/migrations/content/labels, build/env names, Testing artifact và checklist sau khi có chỉ thị deploy; không bịa version/link/QR chưa upload.
11. **next-agent.md:** luồng auth đang dùng, modules/owner, đang thiếu gì/ai phụ trách, cách chạy từ checkout sạch, điểm không được làm.

Cập nhật `docs/features/f07/` scope/api nếu cần/test/report/manifest phù hợp. Phân biệt report lịch sử và kết quả mới; không ghi “NOT_RUN none” trong khi chưa test MySQL/device/provider production. Link vào index/shared docs bằng patch tối thiểu do lead điều phối.

Draft PR trên đúng nhánh F07: vấn đề người dùng, resulting behavior, phạm vi API/schema/shared, cách kiểm thử, privacy invariants, tests evidence, NOT_RUN và dependency thực. Không dùng số lượng tests thay bằng chứng luồng.

## 20. Tiêu chuẩn hoàn thành và câu trả lời cuối

Chỉ ghi **F07 implementation verified trong môi trường đã test** khi:

- Người dùng đi được vào F07 từ Mini App chính thức bằng login HS/PH thật của môi trường test, không qua SDK legacy hoặc demo ngầm.
- Save/history/detail/edit/summary/entry-shares/preview/share/recipient/revoke đều gọi API thực, có loading/error và không phải UI tĩnh.
- F01 connection/F15 grants/session/deletion integration thật; private default, admin deny, revision/generation/ID và re-share/revoke/unlink được kiểm bằng negative tests.
- Race/validation/pagination/resource bounds đúng; migrations và MySQL checks ở mức cần thiết. Device chưa kiểm chứng phải để pending đúng phạm vi, không gọi Done toàn hệ thống.
- UI phù hợp brand/a11y, cache/private-state cleanup, API errors có feedback; không catch rỗng hoặc dùng fixture sai shape để tests xanh.
- Nhánh F07 cập nhật main, không sửa web/F02/main refs; shared changes tương thích và có report merge/regression.
- Đội 10 vai trò đã làm việc/được điều phối theo khả năng tool, reviewer độc lập có bằng chứng; docs đủ để agent sau vận hành và hiểu luồng hiện hành.
- Push đúng nhánh F07 và Draft PR hoàn chỉnh; **chưa merge main, chưa deploy, chưa đụng dữ liệu production**.

Final report cho Huy phải có: branch/PR/head SHA; tính năng đã dùng được; demo/test flow ngắn; những bug thật đã sửa; test results theo môi trường; open blockers/approval/device/MySQL còn thiếu; xác nhận không động web/F02/main; và link tài liệu bàn giao Antigravity. Nếu có lý do chưa đủ nghiệm thu, nêu bằng chứng và next action thay vì viết “hoàn thành 100%”.

**Hãy làm liên tục, phối hợp và phản biện cho tới kết quả thật. Không dừng ở việc đọc, lên kế hoạch hoặc chạy lại 19 tests module cũ rồi tuyên bố F07 hoàn chỉnh.**
