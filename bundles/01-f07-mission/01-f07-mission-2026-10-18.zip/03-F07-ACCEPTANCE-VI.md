# F07: đầu ra phải hoàn thành và bằng chứng nghiệm thu

## Kết quả người dùng cần
Học sinh/người chăm sóc đăng nhập đúng tài khoản, chọn cảm xúc/ngày và ghi chú, lưu riêng tư, xem lịch sử và sửa mục của chính mình. Người viết tự chọn từng mục muốn cho đúng người đồng hành xem, xem trước đầy đủ nội dung, xác nhận chia sẻ và rút quyền từng mục. Người nhận chỉ đọc phần còn quyền; kết nối sẵn không mở hết lịch sử.

Đường đi phải tồn tại trong **Mini App chính thức**, không chỉ packages/mobile harness. Chat mới phải đưa URL thật sau khi chạy, không được giả endpoint hoặc route mood đã đăng ký.

## Bảng nghiệm thu
| Mã | Thử gì | PASS |
| --- | --- | --- |
| F07-01 | HS/PH đăng nhập thật local qua class-session | Session/user UUID/role từ server, không lấy role preview làm quyền |
| F07-02 | Mở tính năng từ navigation thật | Có màn tạo/lịch sử/quản lý share và phía nhận, gọi API thật |
| F07-03 | Tạo mục hôm nay + ghi chú | Lưu backend đúng owner, private default |
| F07-04 | Mở lại/đăng nhập lại | Dữ liệu đã lưu vẫn còn, không chỉ state trình duyệt |
| F07-05 | Tạo trùng ngày, đồng thời hai request | Hợp đồng một mục/ngày nhất quán, lỗi được xử lý; MySQL evidence riêng |
| F07-06 | Sửa mục | Đúng owner, revision mới, không sửa mất mục khác |
| F07-07 | NgàyVN/format/bounds/Unicode/ghi chú2000 | Validate đúng contract; quá giới hạn từ chối rõ, không cắt thầm |
| F07-08 | Lịch sử/summary/phân trang | Đúng người, không N+1, bounded, không điểm/xếp hạng cảm xúc |
| F07-09 | Tài khoản khác/admin gọi list/detail/PATCH/summary | Không đọc/sửa dữ liệu riêng bằng đổi ID hoặc vai trò |
| F07-10 | Chưa kết nối | Vẫn lưu riêng được; share bị chặn có giải thích |
| F07-11 | Cặp admin_provisioned active inviteNULL | Canonical connection dùng được; không hỏi ghép đôi lần nữa |
| F07-12 | Chọn một mục, một người nhận, preview | Preview gồm đúng phần thực sự được chia sẻ, cả note nếu server trả note |
| F07-13 | Sửa nội dung sau preview rồi xác nhận cũ | Không chia sẻ revision chưa duyệt, báo stale để xem lại |
| F07-14 | Xác nhận share | Grant đúng item/recipient/revision/connection-generation, không tự gửi |
| F07-15 | Người nhận đọc/list | Chỉ đúng mục còn quyền, không lộ mục/người khác qua metadata |
| F07-16 | Thu hồi một mục/người nhận | Lần đọc API tiếp bị chặn; các quyền khác giữ đúng |
| F07-17 | Thu hồi rồi share lại | Thật sự có quyền mới đúng contract, không trả grant revoked như thành công |
| F07-18 | Sửa mục đã share | Nội dung mới riêng cho tới khi duyệt share lại; bản stale không đọc tiếp |
| F07-19 | Hủy kết nối/kết nối lại | Không dùng grant generation cũ; không hồi sinh quyền |
| F07-20 | Provider/connection reader chưa đăng ký hoặc lỗi | Failclosed cho nội dung riêng, không bỏ qua kiểm tra |
| F07-21 | F15 overview/revoke | Có provider thực, không chỉ TODO/harness; revoke ở F15 chặn phía F07 |
| F07-22 | Yêu cầu xóa/lifecycle đã có | Theo contract thật, không hứa đã xóa mọi backup; không đọc lại sau mất quyền |
| F07-23 | Logout/đổi actor/phản hồi đến muộn/resume | Bỏ state cũ, không hiển thị hoặc ghi vào actor mới |
| F07-24 | Mất mạng/timeout/bấm lặp | Giữ nháp hợp lý, lỗi rõ, đối chiếu kết quả không tự share lại |
| F07-25 | Màn320/390/430, bàn phím,200%chữ, focus | Đọc/bấm được, CTA không che, logo đúng, help không bị chặn |

Không ghi PASS trước khi quan sát thực. Mỗi dòng ghi sourceSHA, command/URL, fixture, expected, actual và screenshot/payload đã khử nội dung riêng.

## Những môi trường cần phân biệt
- Feature-lab/mock tests: kiểm tra module, chưa chứng minh wiring production.
- Django backend thực + SQLite local + hai user synthetic: integration local.
- MySQL/TiDB test riêng: migrations/concurrency/unique thật.
- Browser: không thay Zalo Android/iOS.
- Production hiện hữu: không dùng tài khoản thật để thử sửa/xóa/thu hồi khi chưa có phạm vi riêng.

## Thầy duyệt nội dung
US-015/026 và N02 gồm nội dung/nhãn gợi ý cần duyệt. Allowlist hiện có là nguồn kỹ thuật, không tự tuyên bố đã phê duyệt chuyên môn. UI mock hoặc dữ liệu synthetic không phải kết quả nghiên cứu.

